Attribute VB_Name = "modVillaScopeEntry"
Option Explicit

' Windows Excel, 32-bit or 64-bit. No VBProject access or added references needed.
Public Const VSR_REVIEW_REQUIRED As Long = vbObjectError + 2101

Private Type ScopeGuid
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type

Private Type ScopeSystemTime
    wYear As Integer
    wMonth As Integer
    wDayOfWeek As Integer
    wDay As Integer
    wHour As Integer
    wMinute As Integer
    wSecond As Integer
    wMilliseconds As Integer
End Type

#If VBA7 Then
    Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef value As ScopeGuid) As Long
    Private Declare PtrSafe Sub GetSystemTime Lib "kernel32" (ByRef value As ScopeSystemTime)
#Else
    Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef value As ScopeGuid) As Long
    Private Declare Sub GetSystemTime Lib "kernel32" (ByRef value As ScopeSystemTime)
#End If

Public Sub ShowVillaScopeEntry()
    On Error GoTo Failed
    CheckTargetWorkbook ThisWorkbook
    frmVillaScopeEntry.Show vbModal
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Villa Scope Register"
End Sub

Public Sub SetupVillaScopeButton()
    Dim page As Worksheet, candidatePage As Worksheet
    Dim button As Object, oldButton As Shape, candidateShape As Shape
    Dim stepName As String, message As String, errorNumber As Long
    Dim buttonInstalled As Boolean
    On Error GoTo Failed

    stepName = "check the workbook and register tables"
    CheckTargetWorkbook ThisWorkbook

    stepName = "find the Entry Form sheet"
    For Each candidatePage In ThisWorkbook.Worksheets
        If StrComp(candidatePage.Name, "Entry Form", vbTextCompare) = 0 Then
            Set page = candidatePage
            Exit For
        End If
    Next candidatePage
    If page Is Nothing Then
        stepName = "create the Entry Form sheet"
        If ThisWorkbook.ProtectStructure Then
            Err.Raise vbObjectError + 2114, , "The workbook structure is protected. Use an editable copy before installing the button."
        End If
        Set page = ThisWorkbook.Worksheets.Add(Before:=ThisWorkbook.Worksheets(1))
        page.Name = "Entry Form"
        page.Range("A1").Value2 = "Villa Scope Register"
        page.Range("A1").Font.Size = 20
        page.Range("A1").Font.Bold = True
        page.Range("A3").Value2 = "Use Add Villa / Scope for a new entry. Save the workbook to sync it to OneDrive."
        page.Columns("A").ColumnWidth = 110
    End If

    stepName = "check the Entry Form sheet is editable"
    If page.ProtectContents Or page.ProtectDrawingObjects Then
        Err.Raise vbObjectError + 2115, , "The Entry Form sheet is protected. Use an editable sheet before installing the button."
    End If

    stepName = "find a previous launch button"
    For Each candidateShape In page.Shapes
        If StrComp(candidateShape.Name, "VSR_AddEntry", vbTextCompare) = 0 Then
            Set oldButton = candidateShape
            Exit For
        End If
    Next candidateShape

    ' Use Excel's native Forms button, rather than a shape's text frame.
    ' Build and assign the new button before replacing the previous one.
    stepName = "create the Excel Forms button"
    Set button = page.Buttons.Add(20, 100, 220, 42)
    stepName = "set the button caption"
    button.Caption = "Add Villa / Scope"
    stepName = "assign ShowVillaScopeEntry to the button"
    button.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!ShowVillaScopeEntry"

    stepName = "replace the previous launch button"
    If Not oldButton Is Nothing Then oldButton.Delete
    stepName = "name the launch button"
    button.Name = "VSR_AddEntry"
    buttonInstalled = True

    stepName = "update the Entry Form status"
    If CStr(page.Range("A1").Value2) = "Villa Scope Register" Then
        page.Range("A4").MergeArea.Cells(1, 1).Value2 = "Popup installed. Use Add Villa / Scope below."
    End If
    stepName = "open the Entry Form sheet"
    page.Activate
    stepName = "save the workbook"
    ThisWorkbook.Save
    If Not ThisWorkbook.Saved Then
        MsgBox "The button is installed in this open workbook, but the save was not completed." & vbCrLf & _
            "Use Ctrl+S before closing it.", vbExclamation, "Workbook save needed"
    Else
        MsgBox "The Add Villa / Scope button is ready.", vbInformation, "Villa Scope Register"
    End If
    Exit Sub

Failed:
    errorNumber = Err.Number
    message = Err.Description
    On Error Resume Next
    If Not buttonInstalled And Not button Is Nothing Then button.Delete
    On Error GoTo 0
    message = "Setup stopped while trying to " & stepName & "." & vbCrLf & _
        "Error " & CStr(errorNumber) & ": " & message
    If buttonInstalled Then
        message = message & vbCrLf & "The button exists in this open workbook. Try Ctrl+S before closing it."
    End If
    MsgBox message, vbExclamation, "Villa Scope setup details"
End Sub

Public Function NewScopeEntryID() As String
    Dim value As ScopeGuid, result As String, i As Long
    If CoCreateGuid(value) <> 0 Then Err.Raise vbObjectError + 2102, , "Windows could not generate an entry ID."
    result = Right$("00000000" & Hex$(value.Data1), 8) & "-" & _
             Right$("0000" & Hex$(value.Data2), 4) & "-" & _
             Right$("0000" & Hex$(value.Data3), 4) & "-"
    For i = 0 To 7
        If i = 2 Then result = result & "-"
        result = result & Right$("00" & Hex$(value.Data4(i)), 2)
    Next i
    NewScopeEntryID = "VSR-" & LCase$(result)
End Function

Public Function SaveNewVillaScope(ByVal target As Workbook, _
    ByVal stage As String, ByVal villa As String, ByVal scopeType As String, _
    ByVal description As String, ByVal colour As String, _
    ByVal villaPDF As String, ByVal scopePDF As String, _
    ByVal nexviaPOs As String, ByVal knotwoodPOs As String, ByVal palmLakesPOs As String, _
    ByRef savedToDisk As Boolean) As String

    Dim scopes As ListObject, references As ListObject, scopeRow As ListRow
    Dim poRow As ListRow, poRows As Collection, poCreated As Collection
    Dim orders As Collection, order As Variant, entryID As String
    Dim created As Boolean, scopeCreated As Boolean, keepEvents As Boolean
    Dim message As String, pending As String, rollbackProblem As Boolean, i As Long
    Dim originalNumber As Long

    savedToDisk = False
    CheckTargetWorkbook target
    stage = Trim$(stage): villa = Trim$(villa): scopeType = Trim$(scopeType)
    description = Trim$(description): colour = Trim$(colour)
    villaPDF = Trim$(villaPDF): scopePDF = Trim$(scopePDF)
    RequireText stage, "Stage"
    RequireText villa, "Villa"
    RequireText scopeType, "Scope Type"
    RequireText description, "Scope Description"
    RequireText colour, "Colour"
    CheckPDFLink villaPDF, "Villa PDF"
    CheckPDFLink scopePDF, "Scope PDF"

    Set scopes = RegisterTable(target, "VillaScopes")
    Set references = RegisterTable(target, "POReferences")
    Set orders = ParsePOReferences(nexviaPOs, knotwoodPOs, palmLakesPOs)
    entryID = NewScopeEntryID()
    If Not scopes.DataBodyRange Is Nothing Then
        If Application.CountIf(scopes.ListColumns("ScopeEntryID").DataBodyRange, entryID) > 0 Then
            Err.Raise vbObjectError + 2103, , "The generated entry ID already exists. No entry was added."
        End If
    End If
    Set poRows = New Collection
    Set poCreated = New Collection
    keepEvents = Application.EnableEvents
    On Error GoTo WriteFailed
    Application.EnableEvents = False

    Set scopeRow = EmptyOrNewRow(scopes, scopeCreated)
    PutText scopeRow, scopes, "ScopeEntryID", entryID
    PutText scopeRow, scopes, "Stage", stage
    PutText scopeRow, scopes, "Villa", villa
    PutText scopeRow, scopes, "ScopeType", scopeType
    PutText scopeRow, scopes, "ScopeDescription", description
    PutText scopeRow, scopes, "Colour", colour
    PutText scopeRow, scopes, "VillaPDFURL", villaPDF
    PutText scopeRow, scopes, "ScopePDFURL", scopePDF

    If Len(villaPDF) = 0 Then pending = "Villa PDF pending. "
    If Len(scopePDF) = 0 Then pending = pending & "Scope PDF pending."
    PutOptional scopeRow, scopes, "NeedsReview", (Len(pending) > 0)
    PutOptional scopeRow, scopes, "ReviewReason", Trim$(pending)
    PutOptional scopeRow, scopes, "LastUpdatedAtUTC", UTCNow()

    For Each order In orders
        Set poRow = EmptyOrNewRow(references, created)
        poRows.Add poRow
        poCreated.Add created
        PutText poRow, references, "ScopeEntryID", entryID
        PutText poRow, references, "POSystem", CStr(order(0))
        PutText poRow, references, "PONumber", CStr(order(1))
        ' No source-email/PDF evidence is fabricated for manually entered POs.
    Next order

    Application.EnableEvents = keepEvents
    SaveNewVillaScope = entryID
    On Error GoTo SaveFailed
    target.Save
    savedToDisk = target.Saved
    Exit Function

SaveFailed:
    ' Rows already exist. Return their ID instead of inviting a duplicate insert.
    savedToDisk = False
    Exit Function

WriteFailed:
    message = Err.Description
    originalNumber = Err.Number
    On Error Resume Next
    For i = poRows.Count To 1 Step -1
        Err.Clear
        Set poRow = poRows(i)
        If CBool(poCreated(i)) Then poRow.Delete Else poRow.Range.ClearContents
        If Err.Number <> 0 Then rollbackProblem = True
    Next i
    If Not scopeRow Is Nothing Then
        Err.Clear
        If scopeCreated Then scopeRow.Delete Else scopeRow.Range.ClearContents
        If Err.Number <> 0 Then rollbackProblem = True
    End If
    Application.EnableEvents = keepEvents
    On Error GoTo 0
    If rollbackProblem Then
        Err.Raise VSR_REVIEW_REQUIRED, , "A write failed and some new rows could not be removed. " & _
            "Review entry " & entryID & " in both tables before adding it again. Original error: " & message
    Else
        Err.Raise originalNumber, , "No new entry was retained. " & message
    End If
End Function

Public Function FindMatchingEntry(ByVal target As Workbook, ByVal stage As String, _
    ByVal villa As String, ByVal scopeType As String, ByVal description As String, ByVal colour As String) As String
    Dim table As ListObject, row As ListRow
    Set table = RegisterTable(target, "VillaScopes")
    For Each row In table.ListRows
        If SameText(ReadText(row, table, "Stage"), stage) And _
           SameText(ReadText(row, table, "Villa"), villa) And _
           SameText(ReadText(row, table, "ScopeType"), scopeType) And _
           SameText(ReadText(row, table, "ScopeDescription"), description) And _
           SameText(ReadText(row, table, "Colour"), colour) Then
            FindMatchingEntry = ReadText(row, table, "ScopeEntryID")
            Exit Function
        End If
    Next row
End Function

Public Function ParsePOReferences(ByVal nexvia As String, ByVal knotwood As String, ByVal palmLakes As String) As Collection
    Dim result As New Collection, seen As Object, groups As Variant, group As Variant
    Dim reference As Variant, value As String, key As String, text As String
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    groups = Array(Array("Nexvia", nexvia), Array("Knotwood", knotwood), Array("Palm Lakes", palmLakes))
    For Each group In groups
        text = Replace(Replace(CStr(group(1)), vbCrLf, vbLf), vbCr, vbLf)
        text = Replace(text, ";", vbLf)
        For Each reference In Split(text, vbLf)
            value = Trim$(CStr(reference))
            If Len(value) > 0 Then
                RequireText value, CStr(group(0)) & " PO"
                key = CStr(group(0)) & "|" & value
                If Not seen.Exists(key) Then
                    seen.Add key, True
                    result.Add Array(CStr(group(0)), value)
                End If
            End If
        Next reference
    Next group
    Set ParsePOReferences = result
End Function

Private Sub CheckTargetWorkbook(ByVal target As Workbook)
    Dim scopes As ListObject, references As ListObject
    If target.ReadOnly Then Err.Raise vbObjectError + 2104, , "This workbook is read-only. Open an editable copy first."
    If Len(target.Path) = 0 Or target.FileFormat <> xlOpenXMLWorkbookMacroEnabled Then
        Err.Raise vbObjectError + 2105, , "First save this workbook as Excel Macro-Enabled Workbook (*.xlsm)."
    End If
    Set scopes = RegisterTable(target, "VillaScopes")
    Set references = RegisterTable(target, "POReferences")
    RequireColumns scopes, Array("ScopeEntryID", "Stage", "Villa", "ScopeType", "ScopeDescription", "Colour", "VillaPDFURL", "ScopePDFURL")
    RequireColumns references, Array("ScopeEntryID", "POSystem", "PONumber")
    If scopes.Parent.ProtectContents Or references.Parent.ProtectContents Then
        Err.Raise vbObjectError + 2106, , "The register sheets are protected. Use an editable register before adding entries."
    End If
End Sub

Private Function RegisterTable(ByVal target As Workbook, ByVal name As String) As ListObject
    Dim sheet As Worksheet, table As ListObject
    For Each sheet In target.Worksheets
        For Each table In sheet.ListObjects
            If StrComp(table.Name, name, vbTextCompare) = 0 Then
                Set RegisterTable = table
                Exit Function
            End If
        Next table
    Next sheet
    Err.Raise vbObjectError + 2107, , "Excel table " & name & " was not found. Check Table Design > Table Name."
End Function

Private Sub RequireColumns(ByVal table As ListObject, ByVal columns As Variant)
    Dim name As Variant, column As ListColumn
    For Each name In columns
        Set column = Nothing
        On Error Resume Next
        Set column = table.ListColumns(CStr(name))
        On Error GoTo 0
        If column Is Nothing Then Err.Raise vbObjectError + 2108, , "Table " & table.Name & " is missing column " & CStr(name) & "."
    Next name
End Sub

Private Function EmptyOrNewRow(ByVal table As ListObject, ByRef created As Boolean) As ListRow
    Dim row As ListRow
    created = False
    For Each row In table.ListRows
        If Application.CountA(row.Range) = 0 Then
            Set EmptyOrNewRow = row
            Exit Function
        End If
    Next row
    Set EmptyOrNewRow = table.ListRows.Add
    created = True
End Function

Private Sub PutText(ByVal row As ListRow, ByVal table As ListObject, ByVal column As String, ByVal value As String)
    Dim cell As Range
    Set cell = row.Range.Cells(1, table.ListColumns(column).Index)
    cell.NumberFormat = "@"
    cell.Value2 = value
    If cell.HasFormula Then Err.Raise vbObjectError + 2109, , "Text was interpreted as a formula in " & column & "."
End Sub

Private Sub PutOptional(ByVal row As ListRow, ByVal table As ListObject, ByVal column As String, ByVal value As Variant)
    Dim target As ListColumn
    On Error Resume Next
    Set target = table.ListColumns(column)
    On Error GoTo 0
    If target Is Nothing Then Exit Sub
    If VarType(value) = vbString Then
        PutText row, table, column, CStr(value)
    Else
        row.Range.Cells(1, target.Index).Value = value
        If VarType(value) = vbDate Then row.Range.Cells(1, target.Index).NumberFormat = "yyyy-mm-dd hh:mm:ss"
    End If
End Sub

Private Function ReadText(ByVal row As ListRow, ByVal table As ListObject, ByVal column As String) As String
    ReadText = CStr(row.Range.Cells(1, table.ListColumns(column).Index).Value2)
End Function

Private Function SameText(ByVal first As String, ByVal second As String) As Boolean
    SameText = (StrComp(Trim$(first), Trim$(second), vbTextCompare) = 0)
End Function

Private Sub RequireText(ByVal value As String, ByVal name As String)
    If Len(Trim$(value)) = 0 Then Err.Raise vbObjectError + 2110, , name & " is required."
    If Len(value) > 32767 Then Err.Raise vbObjectError + 2111, , name & " exceeds Excel's cell length limit."
End Sub

Private Sub CheckPDFLink(ByVal value As String, ByVal name As String)
    If Len(value) = 0 Then Exit Sub
    If LCase$(Left$(value, 8)) <> "https://" Or Len(value) <= 8 Or _
       InStr(value, vbCr) > 0 Or InStr(value, vbLf) > 0 Or InStr(value, vbTab) > 0 Then
        Err.Raise vbObjectError + 2112, , name & " needs an online https:// link from OneDrive Copy link. Local C-drive paths will not work in Power BI."
    End If
    If Len(value) > 32767 Then Err.Raise vbObjectError + 2113, , name & " exceeds Excel's cell length limit."
End Sub

Private Function UTCNow() As Date
    Dim value As ScopeSystemTime
    GetSystemTime value
    UTCNow = DateSerial(value.wYear, value.wMonth, value.wDay) + TimeSerial(value.wHour, value.wMinute, value.wSecond)
End Function
