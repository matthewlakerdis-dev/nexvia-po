Attribute VB_Name = "modVillaScopeSelfTests"
Option Explicit

' Run manually in Windows Excel after installing the module and UserForm.
' Uses a new temporary workbook, never the user's register data.
Public Sub RunVillaScopeSelfTests()
    Dim testBook As Workbook, scopes As ListObject, orders As ListObject
    Dim entryID As String, secondID As String, saved As Boolean, failedCode As Long
    Dim output As String, temporaryPath As String, keepAlerts As Boolean
    Dim failure As String, passed As Long, references As Collection
    keepAlerts = Application.DisplayAlerts
    On Error GoTo Failed

    Set testBook = Application.Workbooks.Add(xlWBATWorksheet)
    testBook.Worksheets(1).Name = "Villa scopes"
    Set scopes = MakeTable(testBook.Worksheets(1), "VillaScopes", Array( _
        "ScopeEntryID", "Stage", "Villa", "ScopeType", "ScopeDescription", "Colour", _
        "VillaPDFURL", "ScopePDFURL", "NeedsReview", "ReviewReason", "LastUpdatedAtUTC"))
    Set orders = MakeTable(testBook.Worksheets.Add, "POReferences", Array("ScopeEntryID", "POSystem", "PONumber"))
    temporaryPath = Environ$("TEMP") & Application.PathSeparator & NewScopeEntryID() & ".xlsm"
    testBook.SaveAs Filename:=temporaryPath, FileFormat:=xlOpenXMLWorkbookMacroEnabled

    Set references = ParsePOReferences("0007265" & vbCrLf & "0007265;0007266", "REF-TEST", "")
    Check references.Count = 3, "PO lines are deduplicated within their system", passed
    Check CStr(references(1)(1)) = "0007265", "PO references preserve leading zeros", passed

    entryID = SaveNewVillaScope(testBook, "5a", "00162", "Test scope", "Test work", "Test colour", _
        "https://example.invalid/villa.pdf", "", "0007265" & vbLf & "0007265" & vbLf & "0007266", "REF-TEST", "", saved)
    Check saved, "Save reports success after saving the temporary workbook", passed
    Check Left$(entryID, 4) = "VSR-" And Len(entryID) = 40, "Entry ID has UUID format", passed
    Check Application.CountA(scopes.ListColumns("ScopeEntryID").DataBodyRange) = 1, "One scope entry is inserted", passed
    Check scopes.ListColumns("Stage").DataBodyRange.Cells(1, 1).Value2 = "5a", "Stage remains text", passed
    Check scopes.ListColumns("Villa").DataBodyRange.Cells(1, 1).Value2 = "00162", "Villa preserves leading zeros", passed
    Check Application.CountA(orders.ListColumns("PONumber").DataBodyRange) = 3, "Three distinct PO associations are inserted", passed
    Check orders.ListColumns("PONumber").DataBodyRange.Cells(1, 1).Value2 = "0007265", "Saved PO reference remains text", passed
    Check CBool(scopes.ListColumns("NeedsReview").DataBodyRange.Cells(1, 1).Value2), "Pending second PDF is recorded", passed
    Check FindMatchingEntry(testBook, "5A", "00162", "Test scope", "Test work", "Test colour") = entryID, "Duplicate warning finds the matching entry", passed

    On Error Resume Next
    output = SaveNewVillaScope(testBook, "", "162", "Test scope", "Test work", "Test colour", "", "", "", "", "", saved)
    failedCode = Err.Number
    Err.Clear
    On Error GoTo Failed
    Check failedCode <> 0 And Application.CountA(scopes.ListColumns("ScopeEntryID").DataBodyRange) = 1, "Missing stage is rejected before insertion", passed

    On Error Resume Next
    output = SaveNewVillaScope(testBook, "5a", "162", "Test scope", "Test work", "Test colour", "C:\plan.pdf", "", "", "", "", saved)
    failedCode = Err.Number
    Err.Clear
    On Error GoTo Failed
    Check failedCode <> 0 And Application.CountA(scopes.ListColumns("ScopeEntryID").DataBodyRange) = 1, "Local PDF path is rejected before insertion", passed

    scopes.Parent.Protect
    On Error Resume Next
    output = SaveNewVillaScope(testBook, "5a", "162", "Test scope", "Test work", "Test colour", "", "", "", "", "", saved)
    failedCode = Err.Number
    Err.Clear
    On Error GoTo Failed
    scopes.Parent.Unprotect
    Check failedCode <> 0 And Application.CountA(scopes.ListColumns("ScopeEntryID").DataBodyRange) = 1, "Protected sheet is rejected before insertion", passed

    secondID = SaveNewVillaScope(testBook, "5a", "00162", "Another scope", "Other work", "Other colour", _
        "", "", "", "", "", saved)
    Check secondID <> entryID And Application.CountA(scopes.ListColumns("ScopeEntryID").DataBodyRange) = 2, "Same villa can have a second scope with a distinct ID", passed
    Check Application.CountA(orders.ListColumns("PONumber").DataBodyRange) = 3, "Blank PO inputs create no PO rows", passed

    testBook.Close SaveChanges:=False
    Set testBook = Nothing
    Kill temporaryPath
    Application.DisplayAlerts = keepAlerts
    MsgBox CStr(passed) & " checks passed in Windows Excel. The popup still needs its manual UI checks.", vbInformation, "Villa Scope self-tests"
    Exit Sub

Failed:
    failure = Err.Description
    On Error Resume Next
    Application.DisplayAlerts = False
    If Not testBook Is Nothing Then testBook.Close SaveChanges:=False
    If Len(temporaryPath) > 0 Then
        If Len(Dir$(temporaryPath)) > 0 Then Kill temporaryPath
    End If
    Application.DisplayAlerts = keepAlerts
    On Error GoTo 0
    MsgBox "Self-test stopped after " & CStr(passed) & " passed checks: " & failure, vbExclamation, "Self-test failed"
End Sub

Private Function MakeTable(ByVal sheet As Worksheet, ByVal name As String, ByVal headers As Variant) As ListObject
    Dim i As Long
    For i = LBound(headers) To UBound(headers)
        sheet.Cells(1, i + 1).Value2 = CStr(headers(i))
        sheet.Cells(2, i + 1).NumberFormat = "@"
    Next i
    Set MakeTable = sheet.ListObjects.Add(xlSrcRange, sheet.Range(sheet.Cells(1, 1), sheet.Cells(2, UBound(headers) + 1)), , xlYes)
    MakeTable.Name = name
End Function

Private Sub Check(ByVal success As Boolean, ByVal description As String, ByRef passed As Long)
    If Not success Then Err.Raise vbObjectError + 2200, , description
    passed = passed + 1
    Debug.Print "PASS: " & description
End Sub
