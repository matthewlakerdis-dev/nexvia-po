Attribute VB_Name = "modVillaScopeStyle"
Option Explicit

' Optional v1.3 landing page. Existing sheets, register tables and records stay intact.
Private Const HOME_NAME As String = "Register Home"
Private Const HOME_MARKER As String = "VSR_STYLE_HOME_1"

Public Sub SetupVillaScopeHome()
    Dim page As Worksheet, candidate As Worksheet, i As Long
    Dim stepName As String, keepScreenUpdating As Boolean
    Dim message As String, errorNumber As Long
    keepScreenUpdating = Application.ScreenUpdating
    On Error GoTo Failed
    stepName = "check that the workbook can be saved"
    If ThisWorkbook.ReadOnly Then Err.Raise vbObjectError + 2130, , "The workbook is read-only."
    If Len(ThisWorkbook.Path) = 0 Or ThisWorkbook.FileFormat <> xlOpenXMLWorkbookMacroEnabled Then
        Err.Raise vbObjectError + 2131, , "Save your working register as an Excel Macro-Enabled Workbook (.xlsm) first."
    End If
    stepName = "find the Home sheet"
    For Each candidate In ThisWorkbook.Worksheets
        If StrComp(candidate.Name, HOME_NAME, vbTextCompare) = 0 Then
            Set page = candidate
            Exit For
        End If
    Next candidate
    If page Is Nothing Then
        If ThisWorkbook.ProtectStructure Then
            Err.Raise vbObjectError + 2132, , "The workbook structure is protected; a Home sheet cannot be added."
        End If
        Set page = ThisWorkbook.Worksheets.Add(Before:=ThisWorkbook.Worksheets(1))
        page.Name = HOME_NAME
        page.Range("Z1").Value2 = HOME_MARKER
    Else
        If IsError(page.Range("Z1").Value2) Then
            Err.Raise vbObjectError + 2133, , "An unrelated Register Home sheet already exists. Nothing was overwritten."
        End If
        If CStr(page.Range("Z1").Value2) <> HOME_MARKER Or page.ListObjects.Count > 0 Then
            Err.Raise vbObjectError + 2133, , "An unrelated Register Home sheet already exists. Nothing was overwritten."
        End If
    End If
    If page.ProtectContents Or page.ProtectDrawingObjects Then
        Err.Raise vbObjectError + 2134, , "The Home sheet is protected."
    End If

    Application.ScreenUpdating = False
    stepName = "format the Home sheet"
    ' Only the layout owned by this module is rebuilt; no register ranges are touched.
    With page.Range("A1:L34")
        .UnMerge
        .Clear
        .Interior.Color = RGB(243, 246, 250)
        .Font.Name = "Segoe UI"
        .Font.Size = 11
        .Font.Color = RGB(69, 87, 107)
        .VerticalAlignment = xlVAlignCenter
    End With
    page.Columns("A").ColumnWidth = 4
    page.Columns("B:K").ColumnWidth = 11
    page.Columns("L").ColumnWidth = 4
    page.Columns("Z").Hidden = True
    page.Rows("1:34").RowHeight = 20
    page.Tab.Color = RGB(26, 50, 76)
    HomeText page, "B2:K2", "VILLA SCOPE REGISTER", 10, True, RGB(94, 119, 146)
    HomeText page, "B3:K4", "Your villa and scope register", 24, True, RGB(26, 50, 76)
    HomeText page, "B5:K6", "Add scope details, link documents and keep purchase order references together.", 12, False, RGB(99, 115, 133)

    For i = page.Shapes.Count To 1 Step -1
        If Left$(page.Shapes(i).Name, 9) = "VSR_HOME_" Then page.Shapes(i).Delete
    Next i
    stepName = "add and connect the Home buttons"
    HomeButton page, "VSR_HOME_Add", "Add villa / scope", "ShowVillaScopeEntry", _
        page.Range("B8:K10"), True
    HomeText page, "B12:K12", "YOUR REGISTER", 10, True, RGB(94, 119, 146)
    HomeButton page, "VSR_HOME_Scopes", "View villa scopes", "OpenVillaScopeTable", _
        page.Range("B14:F16"), False
    HomeButton page, "VSR_HOME_Orders", "View PO references", "OpenVillaScopePOs", _
        page.Range("G14:K16"), False
    HomeText page, "B17:F18", "Stage, villa, scope, colour and PDF links.", 10, False, RGB(99, 115, 133)
    HomeText page, "G17:K18", "Nexvia, Knotwood and Palm Lakes references.", 10, False, RGB(99, 115, 133)

    HomeText page, "B21:K21", "KEEP THE REPORT UP TO DATE", 10, True, RGB(94, 119, 146)
    HomeText page, "B23:K24", "1   Add an entry using the button above.", 12, False, RGB(26, 50, 76)
    HomeText page, "B25:K26", "2   Save the workbook and let OneDrive finish syncing.", 12, False, RGB(26, 50, 76)
    HomeText page, "B27:K28", "3   Refresh the Power BI semantic model, or wait for its scheduled refresh.", 12, False, RGB(26, 50, 76)
    HomeText page, "B31:K32", "PDF or PO arriving later? Update the existing entry using its ScopeEntryID.", 10, False, RGB(99, 115, 133)

    stepName = "open the Home sheet"
    ThisWorkbook.Activate
    page.Activate
    If Not ActiveWindow Is Nothing Then ActiveWindow.DisplayGridlines = False
    page.Range("B2").Select
    Application.ScreenUpdating = keepScreenUpdating
    stepName = "save the workbook"
    ThisWorkbook.Save
    If ThisWorkbook.Saved Then
        MsgBox "Your new Home sheet is ready. Use Add villa / scope to open the form.", vbInformation, "Register styling"
    Else
        MsgBox "The Home sheet is ready in this open workbook. Use Ctrl+S before closing it.", vbExclamation, "Workbook save needed"
    End If
    Exit Sub
Failed:
    errorNumber = Err.Number
    message = Err.Description
    Application.ScreenUpdating = keepScreenUpdating
    MsgBox "Styling stopped while trying to " & stepName & "." & vbCrLf & _
        "Error " & CStr(errorNumber) & ": " & message & vbCrLf & _
        "Your original Entry Form and register tables have not been changed.", vbExclamation, "Register styling"
End Sub

Private Sub HomeText(ByVal page As Worksheet, ByVal address As String, ByVal caption As String, _
    ByVal size As Single, ByVal bold As Boolean, ByVal colour As Long)
    With page.Range(address)
        .Merge
        .Cells(1, 1).Value2 = caption
        .WrapText = True
        .Font.Size = size
        .Font.Bold = bold
        .Font.Color = colour
    End With
End Sub

Private Sub HomeButton(ByVal page As Worksheet, ByVal name As String, ByVal caption As String, _
    ByVal macroName As String, ByVal area As Range, ByVal primary As Boolean)
    Dim button As Shape
    Set button = page.Shapes.AddShape(msoShapeRoundedRectangle, area.Left, area.Top, area.Width, area.Height)
    With button
        .Name = name
        .OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
        .Placement = xlFreeFloating
        .TextFrame.Characters.Text = caption
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.Characters.Font.Name = "Segoe UI"
        .TextFrame.Characters.Font.Size = 13
        .TextFrame.Characters.Font.Bold = True
        If primary Then
            .Fill.ForeColor.RGB = RGB(26, 50, 76)
            .Line.Visible = msoFalse
            .TextFrame.Characters.Font.Color = vbWhite
        Else
            .Fill.ForeColor.RGB = vbWhite
            .Line.ForeColor.RGB = RGB(213, 223, 233)
            .TextFrame.Characters.Font.Color = RGB(26, 50, 76)
        End If
    End With
End Sub

Public Sub OpenVillaScopeTable()
    OpenRegisterTable "VillaScopes"
End Sub

Public Sub OpenVillaScopePOs()
    OpenRegisterTable "POReferences"
End Sub

Private Sub OpenRegisterTable(ByVal tableName As String)
    Dim page As Worksheet, table As ListObject
    On Error GoTo Failed
    For Each page In ThisWorkbook.Worksheets
        For Each table In page.ListObjects
            If StrComp(table.Name, tableName, vbTextCompare) = 0 Then
                ThisWorkbook.Activate
                page.Activate
                table.HeaderRowRange.Cells(1, 1).Select
                Exit Sub
            End If
        Next table
    Next page
    Err.Raise vbObjectError + 2135, , "Could not find the " & tableName & " table."
Failed:
    MsgBox Err.Description, vbExclamation, "Open register"
End Sub
