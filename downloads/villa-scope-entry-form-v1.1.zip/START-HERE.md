# Villa Scope Entry Form — version 1.1

This package adds an **Add Villa / Scope** popup to a Windows desktop Excel
register stored in OneDrive for Business. Save adds one scope row and its related
PO rows. The PDF links and PO references are optional at entry time. Stage, Villa,
Scope Type, Scope Description and Colour are required.

The package contains a blank `.xlsx` workbook and VBA source. It is **not an
already installed `.xlsm` file**. Follow the one-time installation below. Excel
is not available in the build environment: the VBA has not been compiled or run
there. A self-test macro is included for checks in your desktop Excel.

## Contents

- `Villa-Scope-Register.xlsx`: blank register with `VillaScopes` and `POReferences`.
- `modVillaScopeEntry.bas`: entry ID, validation, table-writing and button code.
- `frmVillaScopeEntry-code.txt`: popup controls and event code.
- `modVillaScopeSelfTests.bas`: optional, recommended desktop Excel self-tests.
- `START-HERE.md`: these instructions.

No real villa entries, PDFs, PO mappings, emails, credentials or cloud URLs are
included. The form makes no external service requests and does not create POs.

Version 1.1's blank workbook matches the supplied register: the original sheets
are **Villa Plans** and **PO References**, with tables **VillaScopes** and
**POReferences**. Their headers and empty table ranges are retained. An
**Entry Form** setup page, text formats, stage/PO-system dropdowns and PDF-link
checks have been added. The launch button appears after the VBA setup step;
the setup page alone is not an installed popup.

## Install once

1. Extract the ZIP into a folder. Keep an unchanged copy of your current register.
2. Either open the included blank workbook, or open your existing register. The
   existing workbook needs these named Excel tables and columns:

   - `VillaScopes`: `ScopeEntryID`, `Stage`, `Villa`, `ScopeType`,
     `ScopeDescription`, `Colour`, `VillaPDFURL`, `ScopePDFURL`.
   - `POReferences`: `ScopeEntryID`, `POSystem`, `PONumber`.

   Additional columns are preserved. Optional source, UTC update and review
   columns are supported where present; this matching workbook uses the core
   columns from the supplied register. Adding to an existing register does not
   migrate/repair its old records or assign missing IDs to them.

3. In desktop Excel, choose **File > Save As > Excel Macro-Enabled Workbook
   (*.xlsm)**. Store it in the intended OneDrive folder. Do not overwrite your
   only existing copy. Use this `.xlsm` as the working register going forward.
4. Press **Alt+F11**. In the VBA editor choose **File > Import File** and import
   `modVillaScopeEntry.bas`. Import `modVillaScopeSelfTests.bas` too if testing.
   Import the `.bas` files; do not paste their `Attribute` header into a code pane.
5. Choose **Insert > UserForm**. Select the new blank form and press **F4**.
   Change its **(Name)** property to exactly `frmVillaScopeEntry` (not Caption).
6. Right-click that form in Project Explorer and choose **View Code**. Replace
   its empty/default code with the entire contents of
   `frmVillaScopeEntry-code.txt`, beginning with `Option Explicit`.
   You do not need to draw controls: they are created when the form opens.
7. Choose **Debug > Compile VBAProject**, then save the workbook. Resolve any
   compile message before continuing. UserForm creation supplies the standard
   Microsoft Forms reference; no programmatic VBA-project access is required.
8. Close the VBA editor. Press **Alt+F8**, select **RunVillaScopeSelfTests**, then
   **Run**. It uses and removes a separate temporary workbook, not your register
   data. The 16 checks are intended to run here; no build-side pass is claimed.
9. Press **Alt+F8**, select **SetupVillaScopeButton**, then **Run**. It checks the
   tables, adds an **Entry Form** sheet/button and saves the workbook.
10. Click **Add Villa / Scope**. Try the manual checks below on a disposable copy
    before using the form for real entries.

Use your organisation's approved macro settings. VBA runs in Windows desktop
Excel, not Excel Online or Mac Excel. The code does not change macro settings.

## Enter a record

1. Click **Add Villa / Scope**.
2. Enter Stage, Villa, Scope Type, Scope Description and Colour. Stage offers
   examples 1–5b and also accepts another stage label.
3. Enter the actual Nexvia, Knotwood and Palm Lakes PO references in their own
   boxes. For multiple references, put **one per line**, or separate with
   semicolons. Repeated references within the same system are deduplicated.
   Commas are not used as separators. Quote/invoice references are not assumed
   to be POs: use only the confirmed mapping.
4. Paste each PDF's **online https:// OneDrive Copy link**. Local C-drive paths
   are rejected. Both PDF fields can be left blank until documents are available.
   A syntactically accepted link is not proof it points to the right PDF: open
   it and verify villa/scope/revision and viewer access.
5. Click **Save entry** once. It is disabled while saving. Cancel/Esc adds no rows.
6. Save generates a stable `VSR-` UUID, writes one scope row and all unique PO
   associations with that ID, then saves the workbook for OneDrive to sync.
   If all five scope fields match an existing entry, a warning offers Cancel
   by default; adding a genuine separate entry remains possible.

If the optional `NeedsReview`/`ReviewReason` columns exist, missing PDFs are noted
there. A link's presence is not approval or document verification. Optional
`LastUpdatedAtUTC` is populated with Windows UTC time. Other source/audit columns
are left untouched or blank; no email evidence is fabricated for manual entry.

## Later PDFs and additional POs

This first form **adds new entries**. To add a later PDF, paste its online link
into the existing `VillaPDFURL` or `ScopePDFURL` cell; retain `ScopeEntryID`.
Review/clear a pending-document note only once it has actually been resolved.

For an additional PO on an existing entry, add a `POReferences` table row with
that same ID and the correct system/reference. Do not use the Add form to create
another scope just because its missing PDF/PO arrived. An edit-existing-entry
form and automatic PDF upload/extraction are not included in this version.

## Saving and errors

Validation runs before insertion. New rows are rolled back if a table write
fails; any unsuccessful rollback is reported with the entry ID for manual review.
If Excel fails only at the workbook-save step, the rows are retained in the open
workbook and the form tells you to use Ctrl+S. **Do not enter that record again.**

Use a single register writer at a time; avoid simultaneous Power Automate/table
writes or another user's entry. Excel does not provide a database transaction
across the two tables. The rollback handles this macro's local write errors,
not concurrent writers, OneDrive conflicts or a crash. Confirm sync status.

## Manual UI checks in a disposable copy

- Open then Cancel/Esc: no added scope or PO rows.
- Omit Stage: a clear validation message; form retains values and no row is added.
- Enter a leading-zero villa and PO, Stage 5a, two unique Nexvia POs and one
  repeated Nexvia PO: one scope, two Nexvia associations, identifiers unchanged.
- Leave the second PDF blank: save succeeds and the missing file remains pending.
- Use a local PDF path: save is rejected and no rows are added.
- Submit the same five scope fields: declining the duplicate warning adds no rows.
- Add another scope/colour for the same villa: distinct ID and separate scope row.
- Close/reopen the `.xlsm` and confirm the saved data and launch button work.

## Power BI

Keep the same Excel table names and relationship:
`VillaScopes[ScopeEntryID]` (one) to `POReferences[ScopeEntryID]` (many).
Power BI reads the saved table data; it does not run the VBA.

If the current query filters for `Villa-Scope-Register.xlsx`, change it to your
working **.xlsm** filename in the online OneDrive/SharePoint connection. Check
that there is exactly one matching file and reload the same two tables. Filter
blank template IDs, preserve identifier columns as Text, and configure refresh.
Display Villa and Scope Type links from their two respective URL columns.

This is a manual entry form. AI Builder/PDF extraction and the earlier capacity
issue are separate from installing/using this form.
